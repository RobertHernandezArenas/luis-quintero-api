const path = require("path");
const config = require("../../../config");

const imagePathEmail = path.join(
	__dirname,
	`../../../../${config.pathFiles.logo}`,
);

const addMail = ({ id, email, activation_code }) => {
	const { host, port, routes } = config.api;

	const activationLink = `${host}:${port}/${routes.user}/${id}/activate?code=${activation_code}`;

	return {
		from: `Luis Quintero Web<${config.nodemailer.admin_email}>`,
		to: `${email}`,
		subject: `🟡 Estas a un paso de activar tu cuenta  hola`,
		text: `Activa tu cuenta dando click en el enlace que hay disponible en este correo`,
		html: `<div style="display: flex;justify-content: center;flex-direction: column;align-items: center;" >
					<div style="display: flex;">
							<img style="width: 50px;" src="cid:logo"/>
               				<h2 style="padding: 0rem 1rem;">Estas solo a un click de activar tu cuenta</h2>
					</div>
               		
               		<p>Estas a un paso de tener acceso a tu cuenta, </p>
               		<p>para ello solo necesitas confirmar este email con el siguiente enlace:</p>
               		<br>
							<a style="
								padding: 0.5rem 1rem;
								color: white;
								background-color: #ff235b;
								border-radius: 0.25rem;
								text-decoration: none;
								margin: 1rem 0;
								font-weight: 600;
							" href="${activationLink}" target="_blank">
                 		Confirmar Cuenta
               		</a>
               		<div>
					<p>${new Date()}</p>
						<p>Tambien puedes copiar el link y pegarlo en la barra de direcciones</p>
               			<p>de tu navegador de confiaza para activar la cuenta manualmente:</p>
               			<pre>${activationLink}</pre>
					</div>
               		<br>
					</div>`,
		attachments: [
			{
				filename: "logo.png",
				path: imagePathEmail,
				cid: "logo",
			},
		],
	};
};

module.exports = addMail;
