import path from "path";
import config from "../../../config";

const imagePathEmail = path.join(
	__dirname,
	`../../../../${config.pathFiles.logo}`,
);

const addMail = ({ email, fullname, subject, message }) => {
	console.log(`
	email: ${email} \n
	fullname: ${fullname} \n
	subject: ${subject} \n
	message: ${message}
	`);

	return {
		from: `${fullname}<${config.nodemailer.auth.user}>`,
		to: email,
		subject: subject,
		text: message,
		html: `
			<div>
				<h1>MENSAJE ENVIADO CON ÉXITO</h1>
			</div>


		`,
		// attachments: [
		// 	{
		// 		filename: "logo.png",
		// 		path: imagePathEmail,
		// 		cid: "logo",
		// 	},
		// ],
	};
};

export default addMail;
