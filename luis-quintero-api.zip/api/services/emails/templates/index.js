const createUserEmail = require( "./createUserEmail");
// const deleteUserEmail = require( "./deleteUserEmail");
const activateUserEmail = require( "./activateUserEmail");
// const deactivateUserEmail = require( "./deactivateUserEmail");
// const newCodeUserEmail = require( "./newCodeUserEmail");
// const sentEmail = require( "./sentEmail)"

const emailTemplates = {
	new_user: createUserEmail,
	// delete_user: deleteUserEmail,
	 activate_user: activateUserEmail,
	// deactivate_user: deactivateUserEmail,
	// new_code_user: newCodeUserEmail,
	// sent_email: sentEmail
};

module.exports =  emailTemplates;
