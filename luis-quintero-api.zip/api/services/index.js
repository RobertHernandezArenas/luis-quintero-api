const processFiles = require("./processFiles");

module.exports = { processFiles };
