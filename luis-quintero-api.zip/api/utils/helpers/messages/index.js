const responseMsg = {
	userCreated:
		"La cuenta se ha creado con éxito, revisa tu correo para activar tu cuenta",
};

module.exports = responseMsg;
