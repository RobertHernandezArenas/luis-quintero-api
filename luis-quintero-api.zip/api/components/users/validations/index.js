const createSchema = require("./createSchema");
// const updateSchema = require("./updateSchema");

const validationSchema = { create: createSchema };

module.exports = validationSchema;
