const usersControllers = require("../../users");
const response = require("../../../routes/response");

const userRoutes = {
	create: (req, res, next) => {
		usersControllers
			.create(req.body)

			.then(msg => {
				response.success(req, res, msg, 201);
			})
			.catch(next);
	},

	findAll: (req, res, next) => {
		usersControllers
			.findAll()
			.then(users => {
				response.success(req, res, { data: users }, 200);
			})
			.catch(next);
	},

	findOne: (req, res, next) => {
		usersControllers
			.findOne(req)
			.then(user => {
				response.success(req, res, user, 200);
			})
			.catch(next);
	},

	update: (req, res, next) => {
		usersControllers
			.update(req.body, req.params.id)
			.then(() => {
				response.success(req, res, { mesagge: "Datos actualizados" }, 200);
			})
			.catch(next);
	},

	remove: (req, res, next) => {
		usersControllers
			.remove(req.params.id)
			.then(() => {
				response.success(
					req,
					res,
					{ message: "Datos borrados con éxito" },
					200,
				);
			})
			.catch(next);
	},

	activate: (req, res, next) => {
		usersControllers
			.activate(req.params.id)
			.then(() => {
				response.success(req, res, { message: "Cuenta activada" }, 200);
			})
			.catch(next);
	},

	deactivate: (req, res, next) => {
		usersControllers
			.deactivate(req.params.id)
			.then(() => {
				response.success(req, res, { message: "Cuenta desactivada" }, 200);
			})
			.catch(next);
	},
	newCode: (req, res, next) => {
		usersControllers
			.newCode(req.body.email)
			.then(() => {
				response.success(req, res, { message: "Código Enviado" }, 200);
			})
			.catch(next);
	},
};

module.exports = userRoutes;
