const routerx = require("express-promise-router");
const middlewares = require("../usersMiddlewares");
const { create, findAll, findOne } = require("./usersCallbackRoutes");

const router = routerx();

router
	.post(
		"/create",
		middlewares.checkIfEmailExists,
		middlewares.validation.create,
		create,
	)
	.get("/", findAll)
	.get("/:id", middlewares.checkIfUserNotExists, findOne);

module.exports = router;
